#include<RcppArmadillo.h>
#include<Rcpp.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;

// [[Rcpp::export]]
double logfx(arma::vec x, arma::vec mu, arma::mat sigma){
  mat L = chol(sigma, "lower");
  vec y = solve(trimatl(L), x - mu);
  vec l = diagvec(L);
  double dens;
  double p = x.n_elem;
  const double pi=4*atan(1);
  dens = -p/2 * log(2 * pi) - sum(log(l)) - sum(y % y)/2;
  return dens;
}

// [[Rcpp::export]]
arma::mat mc(int n, arma::vec mu, arma::mat sigma){
  vec yold, ynew;
  int m = mu.size();
  mat x(m,n+1,fill::zeros);
  for (int i = 0; i < m; ++i){
    for(int j = 1; j< n+1; ++j){
      vec k=vec(Rcpp::rnorm(1,mu(i),sigma(i,i)));
      double xnew=k(0);
      yold = x.col(j-1);
      ynew = x.col(j-1);
      ynew(i)=xnew;

      vec mini(2,fill::zeros);
      mini(1)=logfx(ynew,mu,sigma)-logfx(yold,mu,sigma);
      double b=mini.min();
      double a=exp(b);

      vec acc=vec(Rcpp::rbinom(1,1,a));
      double accept=acc(0);
      if(accept) {x(i,j)=xnew;}
      if(!accept) {x(i,j)=x(i,j-1);}
    }
  }
  return x;
}
