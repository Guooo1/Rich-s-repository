#include<RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;

// [[Rcpp::export]]
arma::vec fastLM0(arma::vec y, arma::mat X) {
  vec betaHat, XtY;
  mat XtX;
  XtX = X.t() * X;
  XtY = X.t() * y;
  betaHat = solve(XtX, XtY);
  return betaHat;
}

// [[Rcpp::export]]
arma::vec LM_gd(arma::vec y, arma::mat x){
  int mark = 5000;
  double epsilon=1e-4;
  int n = x.n_cols;
  vec beta = zeros<vec>(n);
  double fx;
  double t = 0.0001;
  vec grad;
  for(int i=0; i<mark; ++i){
    vec A = (y - x * beta);
    fx = sum(A % A);
    grad = x.t() * x * beta - x.t() * y;
    if(fx < epsilon) break;
    beta = beta - t * grad;
  }
  return beta;
}

// [[Rcpp::export]]
Rcpp::List fast_LM(arma::vec y, arma::mat X) {
  vec betaHat, betaSigma, XtY, residuals;
  mat XtX;
  double sigmaHat;
  int nSample = X.n_rows;
  int pCov = X.n_cols;

  XtX = X.t() * X;
  XtY = X.t() * y;

  betaHat = solve(XtX, XtY);
  residuals = y - X * betaHat;

  sigmaHat = sum(residuals % residuals) / (nSample - pCov);
  sigmaHat = sqrt(sigmaHat);

  betaSigma = sigmaHat * sqrt(diagvec(XtX.i()));
  vec t=(1/betaSigma)%betaHat;
  double ymean=sum(y)/nSample;
  double TSS=sum((y-ymean)%(y-ymean));
  double RSS=sum(residuals%residuals);
  double ESS=TSS-RSS;
  double R2=ESS/TSS;
  double F=(ESS/(pCov))/(RSS/(nSample-pCov-1));
  return Rcpp::List::create(Rcpp::Named("betaHat") = betaHat,
                            Rcpp::Named("betaSigma") = betaSigma,
                            Rcpp::Named("sigmaHat") = sigmaHat,
                            Rcpp::Named("T") = t,
                            Rcpp::Named("R2") = R2,
                            Rcpp::Named("F") = F);
}

