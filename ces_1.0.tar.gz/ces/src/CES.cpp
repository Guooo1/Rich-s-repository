#include<RcppArmadillo.h>
using namespace arma;
// [[Rcpp::depends(RcppArmadillo)]]

double derivA(double A){
  double a = 1/A;
  return a;
}

double derivrow(double K,double L,double row,double Delta){
  double r=log((Delta*(pow(K,-row)-pow(L,-row))+pow(L,-row)))/pow(row,2)-
    (Delta*(log(L)*pow(L,-row)-log(K)*pow(K,-row))-log(L)*pow(L,-row)) / (row* (Delta*(pow(K,-row)-pow(L,-row))+pow(L,-row)));
  return r;
}

double derivDelta(double K,double L,double row,double Delta){
  double d = (pow(L,-row)-pow(K,-row)) / row * (Delta*(pow(K,-row)-pow(L,-row))+pow(L,-row));
  return d;
}

double f(double K,double L,double A,double row,double Delta){
  double lnQ;
  lnQ=log(A)-log(Delta*(pow(K,-row)-pow(L,-row))+pow(L,-row))/row;
  return lnQ;
}

arma::vec fastLM(arma::vec y, arma::mat X) {
  vec betaHat, XtY;
  mat XtX;
  XtX = X.t() * X;
  XtY = X.t() * y;
  betaHat = XtX.i() *  XtY;
  return betaHat;
}

arma::mat iter1(arma::vec y, arma::mat x, double A, double row, double Delta){
  int n=y.size();
  mat z(n,3);
  for (int i=0;i<n;++i){
    double K = x(i,0);
    double L = x(i,1);
    z(i,0)=derivA(A);
    z(i,1)=derivrow(K,L,row,Delta);
    z(i,2)=derivDelta(K,L,row,Delta);
  }
  return z;
}

arma::vec iter2(arma::vec y, arma::mat x, arma::mat z, double A, double row, double Delta){
  int n=y.size();
  vec yn(n);
  for(int i=0;i<n;++i){
    double fi = f(x(i,0),x(i,1),A, row, Delta);
    double muti = z(i,0)* A + z(i,1) * row + z(i,2) * Delta;

    yn(i)=y(i)-fi+muti;
  }
  return yn;
}


// [[Rcpp::export]]
arma::vec ces(arma::vec y, arma::mat x){
  y = log(y);
  vec beta = {0.1,0.2,0.3};
  vec yit;
  mat zit;
  double A,row,Delta;
  for(int i=0;i<50;++i){
    A = beta(0);
    row = beta(1);
    Delta = beta(2);
    if (Delta<0)
      Delta=0.2;
    if (Delta>1)
      Delta=0.8;
    if (row==0)
      row=0.5;
    zit = iter1(y, x, A, row, Delta);
    yit = iter2(y, x, zit, A, row, Delta);
    beta = fastLM(yit, zit);
  }

  return beta;
}



